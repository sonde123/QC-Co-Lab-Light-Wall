#ifndef __MESSAGETYPE3_0_H
#define __MESSAGETYPE3_0_H

//This file provides player support for Version 3 Message Type 0 files.

void PlayFile_3_0(Fat16 &file, LightWall &LW, void (*error_code)(int));

#endif

