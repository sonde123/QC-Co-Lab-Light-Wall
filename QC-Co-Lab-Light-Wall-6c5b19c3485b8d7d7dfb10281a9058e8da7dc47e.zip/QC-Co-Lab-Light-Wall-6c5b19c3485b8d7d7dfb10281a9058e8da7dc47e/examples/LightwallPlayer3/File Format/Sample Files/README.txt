Included are some sample files written by Mark Riedesel (http://klowner.com) for the QC Co-Lab Lightwall.
They are type formatted for a 15x16 lightwall, with 30 lights per strings.